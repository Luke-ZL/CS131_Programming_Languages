fun <T> everyNth(L: List<T>, N: Int) : List<T> {
    if (N < 1) return emptyList()
    val result = ArrayList<T>()
    var i = N-1
    while (i < L.size){
    	  result.add(L[i])
	  i += N
    }
    val returnList: List<T> = result
    return returnList
}

fun main(args: Array<String>) {
    val list1 = listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    val list2 = listOf("a", "b", "c", "d", "e", "f", "g")
    val list3 = listOf<String>()

    val result1 = everyNth(list1, 3)
    val result2 = everyNth(list2, 2)
    val result3 = everyNth(list2, 1)
    val result4 = everyNth(list3, 2)
    val result5 = everyNth(list1, 0)
    val result6 = everyNth(list1, 11)

    if (result1 == listOf(3, 6, 9)) println("Pass test1")
    else println("Fail test1")

    if (result2 == listOf("b", "d", "f")) println("Pass test2")
    else println("Fail test2")

    if (result3 == list2) println("Pass test3")
    else println("Fail test3")

    if (result4.isEmpty()) println("Pass test4")
    else println("Fail test4")

    if (result5.isEmpty()) println("Pass test5")
    else println("Fail test5")

    if (result6.isEmpty()) println("Pass test6")
    else println("Fail test6")
}